  Campa�a = 15
 
  # install.packages('plotly')
  # install.packages('readx1')
  
  library(plotly)
  library(hms)
  library(tibble)
  library(readxl)
  library(Rfast)
  library(compareDF)
  library(stringi)
  
  Campa�a = 15 #cambiar el numero dependiendo la campa�a
  #Dias = list.files(path = "C:\\Users\\Pedro Vallarino\\Desktop\\Proyecto OVA Productividad\\C15 TM Productividad\\x segmento")
  Dias = list.files(path = "C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C 15 TM Productividad\\x usuario")
  Dias = length(Dias)
  
  Cero = 0
  Directorio = 0 #las defino antes para que no me salte el error de Object not found
  mylist = 0
  Posiciones = 0

  Usuarios <- read_excel("C:/Users/VallariP/Desktop/Archivos de Referencia/Usuarios.xlsx")
  Usuarios = select(Usuarios,c(1,5))
  
  for (k in 1:Dias) {
    if (k >= 10) {
      Cero= ""
    }
    Directorio[k] = paste("C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C ",Campa�a, " TM Productividad\\x usuario\\TM D",Cero,k,".csv",sep = "")
    #Directorio[k] = paste("C:\\Users\\Pedro Vallarino\\Desktop\\Proyecto OVA Productividad\\C",Campa�a, " TM Productividad\\x usuario\\TM D",Cero,k,".csv",sep = "")
    
    TM= read.csv(Directorio[k],header=TRUE, sep="|")
    TM = select(TM,-c(1,2,12))
    NumUs = length(Usuarios$Usuario)
    
    for (Q in 1:NumUs){
      Nombre = which(TM$Usuario == Usuarios$Usuario[Q]) 
      if (length(Nombre) > 0 ){
        TM$Usuario[Nombre] = Usuarios$Asociado[Q]  
      }
    }
    
    Numfil = length(TM$Usuario)
    
    for(l in 1:Numfil){
      TM[l,2] = stri_sub(TM[l,2],-2)
    }
    
    mylist[k] = list(TM)
    
  }
  
  PlotEst = 0
  PlotEstDias = 0
  AN_E = 0

   # #Graficos por Estacion
  Estacion = c(61:68)
    for (k in 1:Dias){
      TMES = as.data.frame(mylist[[k]])
    for (i in 1:length(Estacion)) {
      TME = slice(TMES,which(TMES$Estatión==Estacion[i]))
      if (dim(TME)[1] == 0) {
        TME = 0
      }
      else{
        AN_E =  plot_ly(TME,x =   TME$Estatión , y =  TME$Productividad.Neta,  type = 'bar',name = TME$Usuario , text = paste(TME$Segmentò," ",TME$Tiempo.Neto," ",TME$Usuario)) %>%
        layout(title = "Productividad por Estacion",
               yaxis = list(title = "Unidades/Hora"),
               margin = list(b = 100),
               barmode = 'group')
        PlotEst[i] = list(AN_E)
        }
      }

      PlotEstDias[k] = list(PlotEst)
}

  remove(AN_E)
  remove(PlotEst)
  remove(TM)
  remove(TMES)
  remove(Directorio)
  remove(Estacion)
  remove(i)
  remove(k)
  remove(l)
  remove(Nombre)
  remove(Numfil)
  remove(NumUs)
  remove(Posiciones)
  remove(Q)
  remove(TME)
  

#Graficos por Usuario
AN_U = 0
PlotUs = 0
PlotUsDias = 0

  
for (k in 1:Dias) {
 TMUS = as.data.frame(mylist[[k]])
 Nombres = names(table(TMUS$Usuario))
 for (i in 1:length(names(table(TMUS$Usuario)))){
 TMU = slice(TMUS,which(TMUS$Usuario==Nombres[i]))
 
 AN_U =  plot_ly(TMU,x =   TMU$Estatión , y =  TMU$Productividad.Neta,  type = 'bar',name = TMU$Usuario , text = TMU$Segmentò , color = "khaki1") %>%
         
 layout(title = paste("Productividad",TMU$Usuario[1]),
        xaxis = list(title = "Estaciones ", tickangle = -45),
        yaxis = list(title = "Productividad por Estacion [uni/h]"),
        margin = list(b = 100),
        barmode = 'group')

 AN_U
 
PlotUs[i] = list(AN_U) 
 
 }
PlotUsDias[k] = list(PlotUs)
}

remove(Cero)
remove(i)
remove(k)
remove(Nombres)
remove(TMU)
remove(TMUS)
remove(PlotUs)
remove(AN_U)

