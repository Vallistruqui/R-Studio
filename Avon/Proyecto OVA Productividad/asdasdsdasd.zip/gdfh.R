## Only run examples in interactive R sessions
if (interactive()) {
  
  ui <- fluidPage(
    numericInput("obs", "Observations:", 10, min = 1, max = 100),
    verbatimTextOutput("value")
  )
  server <- function(input, output) {
  abc <- reactive({
    
    abc <- output$value <- PlotA[[({ input$obs })]]
  }) } 
  
  shinyApp(ui, server)
}