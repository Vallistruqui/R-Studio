#install.packages('plotly')
#install.packages('hms')

Campa�a = 15

library(plotly)
#library(hms) la activo cuando quiera saber cuanto tiempo estuvieron en cada estacion

Campa�a = 15 #cambiar el numero dependiendo la campa�a
Dias = list.files(path = "C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C 15 TM Productividad\\x segmento")
Dias = length(Dias)
Cero = 0
Directorio = 0 #la defino antes para que no me salte el error de Object not found

myAlist = 0
myBlist = 0
myClist = 0

myAPlist = 0
myBPlist = 0
myCPlist = 0

PromA = 0
PromB = 0
PromC = 0

ProdA = 0
ProdB = 0
ProdC = 0

TM_A = 0
TM_AP = 0

TM_B = 0
TM_BP = 0

TM_C = 0
TM_CP = 0

Vector_Dias = 0

PlotAP = 0 
PlotA = 0

for (i in 1:Dias) { 
  if (i >= 10) {
    Cero= ""
  }
  
  Vector_Dias[i] = paste("D",Cero,i,sep="")
  
  
  Directorio[i] = paste("C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C ",Campa�a, " TM Productividad\\x segmento\\TM D",Cero,i," x segmentos.csv",sep = "")
 #Directorio[i] = paste("C:\\Users\\Pedro Vallarino\\Desktop\\Proyecto OVA Productividad\\C",Campa�a," TM Productividad\\x segmento/TM D",Cero,i," x segmentos.csv",sep="")
  TM_temp = read.csv(Directorio[i],header=TRUE, sep="|")
  
  TM_A = slice(TM_temp,1:4)
  TM_A = select(TM_A,c(4,5,6,7))
  PromA = cbind(PromA,TM_A[,1])
  
  TM_AP = slice(TM_temp,1:4)
  TM_AP = select(TM_AP,c(9))
  ProdA = cbind(ProdA,TM_AP[,1])
  
  TM_B = slice(TM_temp,c(5))
  TM_B = select(TM_B,c(4,5,6,7))
  TM_B = rbind(c(0,0,0,0),TM_B,c(0,0,0,0))
  PromB = cbind(PromB,TM_B[,1])
  
  TM_BP = slice(TM_temp,c(5))
  TM_BP = select(TM_BP,c(9))
  ProdB = cbind(ProdB,TM_BP[,1])
  
  TM_C = slice(TM_temp,c(6))
  TM_C = select(TM_C,c(4,5,6,7))
  TM_C = rbind(c(0,0,0,0),TM_C,c(0,0,0,0))
  PromC = cbind(PromC,TM_C[,1])
  
  TM_CP = slice(TM_temp,c(6))
  TM_CP = select(TM_CP,c(9))
  ProdC = cbind(ProdC,TM_CP[,1])
  
  myAlist[i]  = list(TM_A)
  myAPlist[i]  = list(TM_AP)
  
  myBlist[i] = list(TM_B)
  myBPlist[i]  = list(TM_BP)
  
  myClist[i] = list(TM_C)
  myCPlist[i]  = list(TM_CP)
  
}

Cero = 0

remove(TM_A)
remove(TM_B)
remove(TM_C)

remove(TM_AP)
remove(TM_BP)
remove(TM_CP)


ProdA = ProdA[,-1]
PromA = PromA[,-1]
Unidades_AxDia = PromA
Prod_AxDia = ProdA

ProdB = ProdB[,-1]
PromB = PromB[,-1]
Unidades_BxDia = PromB
Prod_BxDia = ProdB

ProdC = ProdC[,-1]
PromC = PromC[,-1]
Unidades_CxDia = PromC
Prod_CxDia = ProdC

Matriz_Scatter = cbind(t(Unidades_AxDia))
Matriz_Scatter = as.data.frame(Matriz_Scatter)

Tendenciaxarea <- plot_ly(Matriz_Scatter,x =   Vector_Dias, y =  Matriz_Scatter$V1,       type = 'scatter',    mode = 'lines', name = 'A1') %>%
                add_trace(y =  Matriz_Scatter$V2,       type = 'scatter',              mode = 'lines', name = 'A2') %>%
                add_trace(y =  Matriz_Scatter$V3,       type = 'scatter',              mode = 'lines', name = 'A3') %>%
                add_trace(y =  Matriz_Scatter$V4,       type = 'scatter',              mode = 'lines', name = 'A4') %>%

layout(title = "Cantidad de Unidades por Area",
    xaxis = list(title = "Dias"),
    yaxis = list(title = "# Unidades"),
    margin = list(b = 100))

Matriz_Scatter2 = cbind(t(Prod_AxDia))
Matriz_Scatter2 = as.data.frame(Matriz_Scatter2)

Tendenciaxarea2 <- plot_ly(Matriz_Scatter2,x =   Vector_Dias, y =  Matriz_Scatter2$V1,       type = 'scatter',    mode = 'lines', name = 'A1') %>%
  add_trace(y =  Matriz_Scatter2$V2,       type = 'scatter',              mode = 'lines', name = 'A2') %>%
  add_trace(y =  Matriz_Scatter2$V3,       type = 'scatter',              mode = 'lines', name = 'A3') %>%
  add_trace(y =  Matriz_Scatter2$V4,       type = 'scatter',              mode = 'lines', name = 'A4') %>%

  layout(title = "Productividad por Area",
         xaxis = list(title = "Dias"),
         yaxis = list(title = "Unidades/Hora"),
         margin = list(b = 100))

SubpA = subplot(Tendenciaxarea,Tendenciaxarea2, shareX = TRUE,titleY = TRUE,nrows = 2) %>%
layout(title = "Cantidad vs Productividad")

#esto seria el grafico para las series A, el dia que me lo pidan lo podriamos ver para todas las areas

PromA = means(PromA)
ProdA = means(ProdA)

PromB = mean(PromB) #se usa rowMeans si es un DF si es solo un vector se usa mean
PromB = c(PromB,PromB,PromB)
ProdB = rowMeans(ProdB)

PromC = mean(PromC)
PromC = c(PromC,PromC,PromC)
ProdC = rowMeans(ProdC)

TargetA = c(15000,15000,15000,15000) #sacar del archivo Scorecard Global
TargetB = c(5000,5000,5000)
TargetC = c(7000,7000,7000)

#https://plot.ly/r/bar-charts/

ZonasA = c("A1","A2","A3","A4")
ZonasB = c("" ,"B1", "")
ZonasC = c("","C1","")

Cero = 0

for (k in 1:Dias) {
  if (k >= 10) {
    Cero= ""
  }
  
TM_AP = as.data.frame(myAPlist[[k]])  
TM_AP = cbind(ZonasA,TM_AP,ProdA)

AN_AP <- plot_ly(TM_AP,x =   TM_AP$ZonasA, y =  TM_AP$Productividad.Neta,   type = 'bar', name = 'Unidades Total', marker = list(color = 'cyan')) %>%
  add_trace(TM_AP,x =   TM_AP$ZonasA, y = TM_AP$ProdA ,       type = 'scatter',              mode = 'lines', name = 'Promedio Uds.Tot Campa�al', marker = list(color = 'darkorchid1')) %>%
  
  layout(title = paste("Productividad lineas A D",Cero,k,sep=""),
         xaxis = list(title = "Areas", tickangle = -45),
         yaxis = list(title = "Unidades/Hora"),
         margin = list(b = 100),
         barmode = 'group')


AN_AP

PlotAP[k] = list(AN_AP)


TM_A = as.data.frame(myAlist[[k]])
TM_A = cbind(ZonasA,TM_A,PromA,TargetA)

AN_A <- plot_ly(  TM_A,x =   TM_A$ZonasA, y =  TM_A$UDS.Total,   type = 'bar',            name = 'Unidades Total', marker = list(color = 'cyan')) %>%
  add_trace(TM_A,x =   TM_A$ZonasA, y =  TM_A$Scanned,     name = 'Escaneados',           marker = list(color = 'chartreuse')) %>%
  add_trace(TM_A,x =   TM_A$ZonasA, y =  TM_A$Pick.Button, name = 'Unidades Pickeadas',   marker = list(color = 'yellow')) %>%
  add_trace(TM_A,x =   TM_A$ZonasA, y =  TM_A$Short.Pick,  name = 'Faltante de Pickeado', marker = list(color = 'orangered')) %>%
  add_trace(TM_A,x =   TM_A$ZonasA, y =  TM_A$PromA,       type = 'scatter',              mode = 'lines', name = 'Promedio Uds.Tot Campa�al', marker = list(color = 'darkorchid1')) %>%
  add_trace(TM_A,x =   TM_A$ZonasA, y =  TM_A$TargetA,     type = 'scatter',              mode = 'lines', name = 'Target', marker = list(color = 'gold')) %>%
  
  layout(title = paste("Comparacion de lineas A D",Cero,k,sep=""),
         xaxis = list(title = "Areas", tickangle = -45),
         yaxis = list(title = "Cantidad de Unidades"),
         margin = list(b = 100),
         barmode = 'group')

PlotA[k] = list(AN_A)

# TM_B = TM_B01  #Elegir el dia a consultar
# TM_B = cbind(ZonasB,TM_B,PromB,TargetB)
# 
# AN_B <- plot_ly(  TM_B,x =   TM_B$ZonasB, y =  TM_B$UDS.Total,   type = 'bar',              name = 'Unidades Total', marker = list(color = 'cyan')) %>%
#   # add_trace(TM_B,x =   TM_B$ZonasB, y =  TM_B$Scanned,     name = 'Escaneados',           marker = list(color = 'chartreuse')) %>%
#   # add_trace(TM_B,x =   TM_B$ZonasB, y =  TM_B$Pick.Button, name = 'Unidades Pickeadas',   marker = list(color = 'yellow')) %>%
#   # add_trace(TM_B,x =   TM_B$ZonasB, y =  TM_B$Short.Pick,  name = 'Faltante de Pickeado', marker = list(color = 'orangered')) %>%
#   add_trace(TM_B,x =   TM_B$ZonasB, y =  TM_B$PromB,       type = 'scatter', mode = 'lines',                name = 'Promedio Uds.Tot Campa�al', marker = list(color = 'darkorchid1')) %>%
#   add_trace(TM_B,x =   TM_B$ZonasB, y =  TM_B$TargetB,     type = 'scatter', mode = 'lines',                name = 'Target', marker = list(color = 'gold')) %>%
#   
#   layout(xaxis = list(title = "", tickangle = -45),
#          yaxis = list(title = ""),
#          margin = list(b = 100),
#          barmode = 'group')
# 
# 
# AN_B
# 
# 
# TM_C = TM_C01  #Elegir el dia a consultar
# TM_C = cbind(ZonasC,TM_C,PromC,TargetC)
# 
# AN_C <- plot_ly(  TM_C,x =   TM_C$ZonasC, y =  TM_C$UDS.Total,   type = 'bar',                  name = 'Unidades Total', marker = list(color = 'cyan')) %>%
#   # add_trace(TM_C,x =   TM_C$ZonasC, y =  TM_C$Scanned,     name = 'Escaneados',           marker = list(color = 'chartreuse')) %>%
#   # add_trace(TM_C,x =   TM_C$ZonasC, y =  TM_C$Pick.Button, name = 'Unidades Pickeadas',   marker = list(color = 'yellow')) %>%
#   # add_trace(TM_C,x =   TM_C$ZonasC, y =  TM_C$Short.Pick,  name = 'Faltante de Pickeado', marker = list(color = 'orangered')) %>%
#   add_trace(TM_C,x =   TM_C$ZonasC, y =  TM_C$PromC,       mode = 'lines',                name = 'Promedio Uds.Tot Campa�al', marker = list(color = 'darkorchid1')) %>%
#   add_trace(TM_C,x =   TM_C$ZonasC, y =  TM_C$TargetC,     mode = 'lines',                name = 'Target', marker = list(color = 'gold')) %>%
#   
#   layout(xaxis = list(title = "", tickangle = -45),
#          yaxis = list(title = ""),
#          margin = list(b = 100),
#          barmode = 'group')
# 
# 
# AN_C

}

remove(i)
remove(k)
remove(ProdA)
remove(ProdB)
remove(ProdC)
remove(PromA)
remove(PromB)
remove(PromC)
remove(TargetA)
remove(TargetB)
remove(TargetC)
remove(Vector_Dias)
remove(ZonasA)
remove(ZonasB)
remove(ZonasC)
remove(Cero)
remove(Directorio)
remove(TM_A)
remove(TM_AP)
remove(TM_temp)
remove(Unidades_AxDia)
remove(Unidades_BxDia)
remove(Unidades_CxDia)
remove(Prod_AxDia)
remove(Prod_BxDia)
remove(Prod_CxDia)
remove(myAlist)
remove(myAPlist)
remove(myBlist)
remove(myBPlist)
remove(myClist)
remove(myCPlist)
remove(AN_A)
remove(AN_AP)
remove(Matriz_Scatter)
remove(Matriz_Scatter2)

#---------------------------------

library(shiny)

# Define UI for app that draws a histogram ----
ui <- fluidPage(
  
  # App title ----
  titlePanel("Hello Shiny!"),
  
  # Sidebar layout with input and output definitions ----
  sidebarLayout(
    
    # Sidebar panel for inputs ----
    sidebarPanel(
      
      # Input: Slider for the number of bins ----
      sliderInput(inputId = "bins",
                  label = "Number of bins:",
                  min = 1,
                  max = 80,
                  value = 100),
      numericInput("numInput", "Ingresa un n�mero:", value = 7, min = 1, max = 30)
      
    ),
    
    # Main panel for displaying outputs ----
    mainPanel(
      
      # Output: Histogram ----
      plotOutput(outputId = "distPlot")
      
    )
  )
)

# Define server logic required to draw a histogram ----
server <- function(input, output) {
  
  # Histogram of the Old Faithful Geyser Data ----
  # with requested number of bins
  # This expression that generates a histogram is wrapped in a call
  # to renderPlot to indicate that:
  #
  # 1. It is "reactive" and therefore should be automatically
  #    re-executed when inputs (input$bins) change
  # 2. Its output type is a plot
  output$distPlot <- renderPlot({
    
    PlotA[[input$numInput]]
    # x    <- faithful$waiting
    # bins <- seq(min(x), max(x), length.out = input$bins + 1)
    # 
    # hist(x, breaks = bins, col = "#75AADB", border = "white",
    #      xlab = "Waiting time to next eruption (in mins)",
    #      main = "Histogram of waiting times")
    # 
  })
  
}

# Create Shiny app ----
shinyApp(ui = ui, server = server)
