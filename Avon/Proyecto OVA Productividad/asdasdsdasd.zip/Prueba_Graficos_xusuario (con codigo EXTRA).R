  #Mes =
  Campa�a = 15
  #Dia = tengo que ver un metodo para que sea modificable el dia a consultar desde aca arriba
  
  # install.packages('plotly')
  # install.packages('hms')
  # install.packages('tibble')
  
  library(plotly)
  library(hms)
  library(tibble)
  library(readxl)
  library(Rfast)
  library(compareDF)
  library(stringi)
  
  Campa�a = 15 #cambiar el numero dependiendo la campa�a
  #Dias = list.files(path = "C:\\Users\\Pedro Vallarino\\Desktop\\Proyecto OVA Productividad\\C15 TM Productividad\\x segmento")
  Dias = list.files(path = "C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C 15 TM Productividad\\x usuario")
  Dias = length(Dias)
  Cero = 0
  Directorio = 0 #la defino antes para que no me salte el error de Object not found
  mylist = 0
  Posiciones = 0
  # HorasX = 0
  # HorasXX = 0
  # TimeDIF = c(0)
  
  #i = 1
  Usuarios <- read_excel("C:/Users/VallariP/Desktop/Archivos de Referencia/Usuarios.xlsx")
  Usuarios = select(Usuarios,c(1,5))
  
  for (k in 1:Dias) {      #cambiar el numero con la cantidad de dias de la campa�a
    if (k >= 10) {
      Cero= ""
    }
    Directorio[k] = paste("C:\\Users\\VallariP\\Desktop\\Proyecto OVA productividad\\R\\C ",Campa�a, " TM Productividad\\x usuario\\TM D",Cero,k,".csv",sep = "")
    #Directorio[k] = paste("C:\\Users\\Pedro Vallarino\\Desktop\\Proyecto OVA Productividad\\C",Campa�a, " TM Productividad\\x usuario\\TM D",Cero,k,".csv",sep = "")
    
    TM= read.csv(Directorio[k],header=TRUE, sep="|")
    
    mylist[k] = list(TM)
    
    # HoraE = as.character(TM$End.Of.Period)
    # HoraB = as.character(TM$�..Begin.Of.Period)
    # 
    # Numfil = length(HoraB)
    # 
    # for (i in 1:Numfil) {
    #   Hora1 = HoraE[i]
    #   Hora1 = strsplit(Hora1, " ")
    #   Hora1 = unlist(Hora1)
    #   HorasX[i] = Hora1[2]
    # }
    # HorasX = head(HorasX,Numfil)
    # HorasE = parse_hms(HorasX)
    # 
    # for (i in 1:Numfil) {
    #   Hora2 = HoraB[i]
    #   Hora2 = strsplit(Hora2, " ")
    #   Hora2 = unlist(Hora2)
    #   HorasXX[i] = Hora2[2]
    # }
    # HorasXX = head(HorasXX,Numfil)
    # HorasB = parse_hms(HorasXX)
    # 
    # TimeDif = as.integer(difftime(HorasE,HorasB))
    # TimeDIF = hms(TimeDif)
    # TimeDIF[which(TimeDIF<0)] = hms(as.integer(TimeDIF[which(TimeDIF<0)] + 43200))
    # TimeDIF= as.data.frame(TimeDIF)
    # HorasE = as.data.frame(HorasE)
    # HorasB = as.data.frame(HorasB)
    # TM = select(TM,3:9)
    # TM = cbind(HorasB,HorasE,TimeDIF,TM)
    # remove(Hora1)
    # remove(Hora2)
    # remove(HoraB)
    # remove(HoraE)
    # remove(HorasB)
    # remove(HorasE)
    # remove(TimeDif)
    # remove(Numfil)
    # 
    # mylist[[k]] = TM
    
    #todo este chino que hice era para tiempo de logeo y no termino sirviendo
    #para mucho, pero lo dejo comentado para el futuro que me acaba de comentar
    #el david que tienen que tener un tiempo minimo de logeo de 6.75hs
    
  }
  
  # remove(HorasX)
  # remove(HorasXX)
  # remove(TM)
  # remove(TimeDIF)
  
  
  Cero = 0
  for (i in 1:Dias) {
    if (i >= 10) Cero= ""
    assign(paste0("TMU",Cero, i), mylist[[i]])
  }
  
  TMU01 = select(TMU01,-c(1,2,12))
  NumUs = length(Usuarios$Usuario)
  
  
  for (Q in 1:NumUs){
  Nombre = which(TMU01$Usuario == Usuarios$Usuario[Q]) 
  if (length(Nombre) > 0 ){
    TMU01$Usuario[Nombre] = Usuarios$Asociado[Q]  
  }
  }
  
  Numfil = length(TMU01$Usuario)
  
  for(l in 1:Numfil){
    TMU01[l,2] = stri_sub(TMU01[l,2],-2)
  }
  
 #-----------------------------------------------------------------------------

    
  #Graficos por Estacion
  Estacion = 62
  TMU61 = slice(TMU01,which(TMU01$Estatión==Estacion))
  lgthVc = length(TMU61$Usuario)
  
  AN_E = 0
  AN_E =  plot_ly(TMU61,x =   TMU61$Estatión , y =  TMU61$Productividad.Neta,  type = 'bar',name = TMU61$Usuario , text = paste(TMU61$Segmentò," ",TMU61$Tiempo.Neto))  %>%
  layout(title = "Productividad por Estacion",
         yaxis =  list(title="unidaes/hora"),
         margin = list(b = 100),
         barmode = 'group')
  
  AN_E  
  
# lo que viene a continuacion es para poder diferenciar los colores de cada uno de los residentes, preguntar en la clase  
#   AN_E = 0
#   lgthVc = length(TMU61$Usuario)
#   color = 0
#   W = 2
#   ctefinal = 0
#   
#   for(W in 1:lgthVc){
#     if (TMU61$Usuario[W+1-ctefinal] != TMU61$Usuario[W]){
#       color[W] = colours()[W*10]
#       }
#       else{
#         color[W] = color[W-1]
#           }
# 
# 
#     TMU61$Usuario[W] = paste(TMU61$Usuario[W],TMU61$Segmentò[W])
# 
#     if (W == lgthVc - 1){
#       ctefinal = 1
#     }
#   }
# 
# 
#   AN_E = 0
#   AN_E = plot_ly()
# 
#   S = 0
# 
# for(S in 1:lgthVc){
# AN_E =  add_trace(TMU61,x =   TMU61$Usuario, y =  TMU61$Productividad.Neta[S],  type = 'bar',name = TMU61$Usuario[S], color =  color[W])
#   }
# 
# # layout(title = paste("Comparacion de lineas A D",Cero,k,sep=""),
# #        xaxis = list(title = "Areas", tickangle = -45),
# #        yaxis = list(title = "Productividad por Estacion"),
# #        margin = list(b = 100),
# #        barmode = 'group')
# 
# AN_E
# 

  #-----------------------------------------------------------------------
  
  #Graficos por Usuario

i = 30

 Nombres = names(table(TMU01$Usuario))
 TMU61 = slice(TMU01,which(TMU01$Usuario==Nombres[i]))
 
 AN_U = 0
 AN_U =  plot_ly(TMU61,x =   TMU61$Estatión , y =  TMU61$Productividad.Neta,  type = 'bar',name = TMU61$Usuario , text = TMU61$Segmentò , color = "khaki1") %>%
         
 layout(title = paste("Productividad",TMU61$Usuario[1]),
        xaxis = list(title = "Estaciones ", tickangle = -45),
        yaxis = list(title = "Productividad por Estacion [uni/h]"),
        margin = list(b = 100),
        barmode = 'group')

 AN_U
